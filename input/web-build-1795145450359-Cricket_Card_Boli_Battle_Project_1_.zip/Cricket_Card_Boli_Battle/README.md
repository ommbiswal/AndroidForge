# Cricket Card Boli Battle

A mobile-friendly cricket card auction game prototype built with Vite and Capacitor.

## Included
- Player vs AI and local 2-player modes
- ₹1,00,000 starting budget per side
- 14 shuffled cards with Legendary, Golden, Silver and Simple rarity
- ₹1,000 bidding increments
- Easy / Medium / Hard scripted AI
- Squad value comparison and simple sound effects

## Build an Android debug APK
Requires Node.js 20, Java 17, and Android SDK / Android Studio:
1. `npm install`
2. `npm run build`
3. `npx cap add android`
4. `npx cap sync android`
5. `cd android && ./gradlew assembleDebug`

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`

This is a prototype, not a signed Play Store release. The two-player mode is local on one device; online multiplayer, accounts, cloud saves, official player photos and team logos are not included. Review player-name/image rights and Play policies before publishing.
