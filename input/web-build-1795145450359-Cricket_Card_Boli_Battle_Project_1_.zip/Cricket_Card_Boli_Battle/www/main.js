import './style.css';

const players = [
  ['Virat Kohli','Legendary',18000,'🏏'],['MS Dhoni','Golden',15000,'🧤'],
  ['Rohit Sharma','Golden',14000,'🔥'],['Jasprit Bumrah','Silver',11000,'⚡'],
  ['Hardik Pandya','Silver',10000,'💥'],['Ravindra Jadeja','Silver',9000,'🌀'],
  ['Shubman Gill','Simple',7000,'🏏'],['Suryakumar Yadav','Simple',7000,'☀️'],
  ['KL Rahul','Simple',6500,'🏏'],['Rishabh Pant','Simple',6500,'🧤'],
  ['Mohammed Siraj','Simple',6000,'⚡'],['Kuldeep Yadav','Simple',5500,'🎯'],
  ['Yuzvendra Chahal','Simple',5000,'🎯'],['Shreyas Iyer','Simple',5000,'🏏']
];
const state = {mode:'ai', difficulty:'Medium', round:0, deck:[], current:null, bids:[0,0], budgets:[100000,100000], teams:[[],[]], turn:0, finished:false, message:'Start a match to begin the auction.'};
const app = document.querySelector('#app');
const money = n => '₹' + n.toLocaleString('en-IN');
function shuffle(a){ return [...a].sort(()=>Math.random()-.5); }
function tone(freq=600,duration=.12){ try { const c=new AudioContext(),o=c.createOscillator(),g=c.createGain(); o.frequency.value=freq;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(.08,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+duration);o.start();o.stop(c.currentTime+duration); } catch{} }
function start(){
 state.round=0;state.deck=shuffle(players);state.current=null;state.bids=[0,0];state.budgets=[100000,100000];state.teams=[[],[]];state.finished=false;state.turn=0;nextCard();
}
function nextCard(){
 if(state.round>=state.deck.length){state.finished=true;state.current=null;state.message='Auction complete!';render();return;}
 state.current=state.deck[state.round++];state.bids=[0,0];state.turn=0;state.message='Bidding starts at ₹1,000. Raise by ₹1,000.';render();
}
function minBid(){return Math.max(state.bids[0],state.bids[1])+1000;}
function bid(who){
 if(!state.current||state.finished)return;
 if(state.budgets[who]<minBid()){state.message=(who===0?'You':'AI')+' do not have enough budget.';render();return;}
 state.bids[who]=minBid();state.turn=1-who;tone(650);
 if(state.mode==='ai'&&who===0) aiTurn();
 render();
}
function aiTurn(){
 const idx=1, card=state.current, base=card[2];
 const factor={Easy:.45,Medium:.72,Hard:1.05}[state.difficulty]||.72;
 const max=Math.min(state.budgets[idx],Math.floor(base*factor/1000)*1000);
 if(state.bids[0]===0 && Math.random()<.25)return;
 if(minBid()<=max && (state.bids[0]===0 || Math.random()<.72)){state.bids[1]=minBid();tone(450);}
}
function finishCard(){
 if(!state.current)return;
 let winner=-1;
 if(state.bids[0]>state.bids[1])winner=0;
 else if(state.bids[1]>state.bids[0])winner=1;
 else if(state.bids[0]>0)winner=Math.random()<.5?0:1;
 if(winner>=0){const price=state.bids[winner];state.budgets[winner]-=price;state.teams[winner].push({...state.current,paid:price});state.message=(winner===0?'You':'AI')+' won '+state.current[0]+' for '+money(price)+'.';tone(850,.22);}
 else state.message=state.current[0]+' went unsold.';
 render();
}
function score(team){return team.reduce((s,p)=>s+p[2],0);}
function render(){
 const card=state.current;
 app.innerHTML=`
 <header><div class="brand">🏆 Cricket Card Boli Battle</div><div class="sub">Build your dream cricket squad through bidding</div></header>
 <main>
 <section class="controls"><label>Game mode <select id="mode"><option value="ai" ${state.mode==='ai'?'selected':''}>Player vs AI</option><option value="local" ${state.mode==='local'?'selected':''}>2 Players (same device)</option></select></label><label>AI difficulty <select id="difficulty"><option ${state.difficulty==='Easy'?'selected':''}>Easy</option><option ${state.difficulty==='Medium'?'selected':''}>Medium</option><option ${state.difficulty==='Hard'?'selected':''}>Hard</option></select></label><button id="start">New Match</button></section>
 <section class="stats"><div><small>Your budget</small><b>${money(state.budgets[0])}</b></div><div><small>${state.mode==='ai'?'AI':'Player 2'} budget</small><b>${money(state.budgets[1])}</b></div><div><small>Cards</small><b>${state.round}/14</b></div></section>
 ${state.finished?`<section class="panel"><h2>🏁 Match result</h2><p>Your squad value: <b>${money(score(state.teams[0]))}</b></p><p>${state.mode==='ai'?'AI':'Player 2'} squad value: <b>${money(score(state.teams[1]))}</b></p><h2>${score(state.teams[0])===score(state.teams[1])?'It is a tie!':score(state.teams[0])>score(state.teams[1])?'🎉 You win!':'🏆 '+(state.mode==='ai'?'AI':'Player 2')+' wins!'}</h2></section>`:card?`
 <section class="panel current"><small>CURRENT PLAYER CARD · ${state.round} OF 14</small><div class="player-icon">${card[3]}</div><h2>${card[0]}</h2><span class="rarity ${card[1].toLowerCase()}">${card[1]}</span><p>Estimated value: <b>${money(card[2])}</b></p><div class="bidline"><span>Your bid: <b>${money(state.bids[0])}</b></span><span>${state.mode==='ai'?'AI':'Player 2'} bid: <b>${money(state.bids[1])}</b></span></div><h3>Next bid: ${money(minBid())}</h3><div class="actions"><button id="bid">Bid ${money(minBid())}</button><button class="secondary" id="pass">Pass / Finish bidding</button></div></section>`:`<section class="panel">${state.message}</section>`}
 <p class="notice">${state.message}</p>
 <section class="squads"><div class="panel"><h3>Your squad (${state.teams[0].length})</h3>${state.teams[0].map(p=>`<p>${p[3]} ${p[0]} · ${money(p.paid)}</p>`).join('')||'<small>No cards yet</small>'}</div><div class="panel"><h3>${state.mode==='ai'?'AI':'Player 2'} squad (${state.teams[1].length})</h3>${state.teams[1].map(p=>`<p>${p[3]} ${p[0]} · ${money(p.paid)}</p>`).join('')||'<small>No cards yet</small>'}</div></section>
 ${card&&!state.finished?'<button id="next" class="next">Confirm result & Next Card</button>':''}
 </main><footer>Prototype game · Player names are illustrative · No official team/player images</footer>`;
 document.querySelector('#mode').onchange=e=>{state.mode=e.target.value;render()};
 document.querySelector('#difficulty').onchange=e=>{state.difficulty=e.target.value};
 document.querySelector('#start').onclick=start;
 const b=document.querySelector('#bid');if(b)b.onclick=()=>bid(0);
 const p=document.querySelector('#pass');if(p)p.onclick=()=>{finishCard();};
 const n=document.querySelector('#next');if(n)n.onclick=nextCard;
}
render();
