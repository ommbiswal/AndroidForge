Cricket Card Boli Battle - v2.1 UI Update

Based on the user's v2.0 project.

Changes:
- Added a fixed bottom navigation bar with Home, Tournament, Friends, Shorts and Profile destinations.
- Added a Game Shorts beta landing panel.
- Added automatic next-card progression 3 seconds after bidding settles. In online mode, the room host advances and publishes the next card so both devices follow the same room state.
- Updated Android version metadata to 2.1 (versionCode 7).

Important limitations:
- Game Shorts is currently a preview/coming-soon panel only. Game Shorts is a watch-only section. Like, Comment and Share actions are intentionally excluded.
- Tournament remains a lobby/ranking feature, not a complete bracket/tournament match engine.
- This ZIP has been checked for archive integrity and JavaScript syntax only. It has not been built with Android Gradle or tested on a physical device in this environment.
