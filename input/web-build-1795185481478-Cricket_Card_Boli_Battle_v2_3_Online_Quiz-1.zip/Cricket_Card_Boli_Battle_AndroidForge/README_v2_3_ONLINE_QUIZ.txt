Cricket Card Boli Battle v2.3 - Online Cricket Quiz Battle

NEW:
- Create a 6-character Online Quiz Room.
- Friend joins with the room code.
- Host starts the 10-question match after the friend joins.
- Both players answer each question on their own phones.
- Each answer is submitted to Firebase Realtime Database.
- The next question appears automatically after both players answer.
- Live score and final winner are synchronized.
- Solo and same-device 2-player modes remain available.

FIREBASE REQUIRED:
1. Firebase Authentication > Sign-in method > Anonymous must remain Enabled.
2. Firebase Realtime Database > Rules: replace with the contents of FIREBASE_RULES_v2_3_ONLINE_QUIZ.json and Publish.
3. Internet access is required on both phones.

BETA SECURITY NOTE:
These rules allow any authenticated user to read/write quiz room data. This is suitable only for closed beta testing, not production or real-money prizes. Client-side scoring can be manipulated; production needs server-side validation and stricter membership rules.
