Cricket Card Boli Battle — Version 2.0

Version 2.0 polish update based on the existing v1.5 project:
- Premium animated card reveal and rarity glow effects.
- Sound ON/OFF toggle; preference saved on the device.
- Expanded player profile shows matches and wins counters (existing counters remain as stored).
- Global Leaderboard listens for Firebase profile changes and refreshes live.
- Tournament Live Ranking panel listens for tournament lobby participant changes.
- Improved ranking medals, panel styling and responsive animation behavior.

Preserved existing v1.5 features: Firebase anonymous sign-in, online rooms, QR display/scanning, both-player Confirm, bidding game, daily reward, XP, profile editing, tournament lobby registration and global leaderboard.

Important beta notes:
- Tournament is still a lobby/participant ranking, not a full knockout/league fixture engine.
- The wins counter is displayed but this update does not yet calculate official online match wins.
- Coins/XP are client-side beta progression, not secure payment or cash-prize balances.
- Build this ZIP with AndroidForge and test on two phones before wider release.
