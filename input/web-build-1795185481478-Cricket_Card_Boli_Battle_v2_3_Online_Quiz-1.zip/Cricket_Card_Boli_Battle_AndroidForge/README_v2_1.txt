Cricket Card Boli Battle - v2.1.3 Navigation Update

Based on the user's v2.1.2 project.

Changes:
- Removed the complete Game Shorts beta section and its placeholder text.
- Kept the bottom navigation: Home, Tournament, Friends and Profile.
- Kept automatic next-card progression 3 seconds after bidding settles. In online mode, the room host advances and publishes the next card so both devices follow the same room state.
- Android version metadata remains versionCode 7 / versionName 2.1.

Limitations:
- Tournament remains a lobby/ranking feature, not a complete bracket/tournament match engine.
- This ZIP is source code for AndroidForge; it has not been built into an APK or tested on a physical device in this environment.
