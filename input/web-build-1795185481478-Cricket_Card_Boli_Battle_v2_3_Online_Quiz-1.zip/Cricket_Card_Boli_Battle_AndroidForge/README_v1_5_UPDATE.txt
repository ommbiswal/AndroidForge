Cricket Card Boli Battle v1.5 update

Included:
- QR code display for a created room.
- QR camera scanner plus manual room code fallback.
- Host/guest Confirm buttons; host starts the match after both confirmations.
- Anonymous Firebase player profile with editable display name.
- Daily reward (100 coins, once per calendar day on this device/account) and XP.
- Firebase-backed top-10 XP leaderboard.
- Tournament lobby registration (open tournament sign-up list).
- Existing bidding game, AI and online room functions retained.

Setup before building:
1. In Firebase Realtime Database > Rules, apply FIREBASE_RULES_UPDATE_v1_5.txt and Publish.
2. Confirm Authentication > Sign-in method > Anonymous is Enabled.
3. Build the project using AndroidForge.
4. Install the new APK. Android may ask for camera permission when Scan QR is first used.

Limitations (honest beta notes):
- Tournament lobby currently supports registration only; bracket scheduling, match pairing and tournament prizes are not yet implemented.
- Missions are currently displayed as guidance, not fully tracked/claimed individually.
- Profile coins and XP are beta client-side values and can be tampered with. No payments or cash prizes.
- QR scan needs internet access to load the scanner library. Manual room code remains available.
- This source has not been built or device-tested in this environment. Please test on two phones before sharing widely.
