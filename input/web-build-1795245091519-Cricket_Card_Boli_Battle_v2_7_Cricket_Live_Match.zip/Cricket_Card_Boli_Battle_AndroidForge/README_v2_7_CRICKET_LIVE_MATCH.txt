CRICKET CARD BOLI BATTLE v2.7

WHAT IS NEW
- New Cricket Live Match game tab.
- Playable quick match versus AI: 2 overs per innings, 3 wickets per innings.
- Batting choices: Defend, Timing, Power Hit.
- Bowling choices: Yorker, Good Length, Bouncer, Spin.
- Wicketkeeper support is represented in the fielding simulation for edges and stumpings.
- Scoreboard, target, wickets, overs, ball-by-ball log and local match history.
- Win reward: 40 in-game coins; XP and match stats are saved to the existing player profile.
- Compact responsive header and 3-column navigation to prevent clipped labels on narrow phones.
- Android window now explicitly fits content between status and navigation bars on Android 11+.

IMPORTANT SCOPE NOTE
This release adds a playable Quick Match versus AI. It is not yet a real-time online cricket PvP engine, full 11-player simulation, or a settled online Cricket League prize tournament. Existing online friend auction, quiz rooms and quiz tournament remain separate. Do not use real money; coins are in-game points only.

BUILD
Upload this ZIP to AndroidForge and build the APK. Firebase Rules are unchanged for this update.
