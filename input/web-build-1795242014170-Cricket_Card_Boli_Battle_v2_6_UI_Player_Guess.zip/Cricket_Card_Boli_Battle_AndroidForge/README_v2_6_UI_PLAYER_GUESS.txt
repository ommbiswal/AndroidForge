CRICKET CARD BOLI BATTLE - VERSION 2.6

What's new:
1. Added Cricket Player Guess mini-game with 10 clue-based rounds, answer feedback, score and XP reward.
2. Rebuilt bottom navigation as a responsive two-row grid so all labels remain visible on small Android screens.
3. Refreshed New Project controls into a clean two-column layout.
4. Improved Tournament, Leaderboard and Friends page spacing and visual styling.
5. Kept existing auction, online friend rooms, Quiz Battle, daily quiz rewards, tournament and profile features.

Build:
Upload this ZIP to AndroidForge and build the APK using the existing workflow.
Firebase Rules: no new Firebase paths are used by this UI/game update.
