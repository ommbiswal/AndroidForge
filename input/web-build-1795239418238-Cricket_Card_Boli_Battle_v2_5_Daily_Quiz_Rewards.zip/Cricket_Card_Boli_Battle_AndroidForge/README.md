# Cricket Card Boli Battle — AndroidForge build project

This ZIP is a native Android Gradle project. The game UI is bundled locally in the Android app and runs in an Android WebView.

- Android Gradle Plugin: 8.7.3
- Java: 17
- compileSdk: 35
- minSdk: 23
- Package: com.ommbiswal.cricketcardbolibattle

Build command: `gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`


Latest update: v2.5 adds Daily Quiz Challenge, automatic virtual coin rewards for the top three after all registered players finish, and tournament history. See README_v2_5_DAILY_QUIZ_REWARDS.txt.
