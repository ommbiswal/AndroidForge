Cricket Card Boli Battle v2.4 - Online Quiz Tournament (Beta)

New features:
- Online Quiz Tournament registration with 50 in-game coin entry fee.
- Coin deduction uses a Firebase Realtime Database transaction to prevent a negative balance.
- Each registered player can submit their first Solo Quiz score to the tournament leaderboard.
- Tournament ranking sorts by quiz score, then XP.
- Tournament prize pool display: 1st 500 coins, 2nd 300 coins, 3rd 150 coins.

How to test:
1. Install/build this ZIP using AndroidForge.
2. Ensure Firebase Anonymous Authentication is enabled and the v2.3 Realtime Database rules remain published.
3. Open Profile and tap Join Tournament Lobby (requires 50 coins).
4. Play one Solo Challenge. Your first score is added to Tournament ranking.
5. Open Tournament tab to see ranking.

Important beta limitations:
- This is an in-game virtual coin feature only; no real money or cash prizes.
- The displayed prize pool is informational; automated prize payout is not implemented in this beta.
- Client-side quiz scoring and broad beta database rules are not cheat-proof. Do not use for paid competitions or valuable prizes. A production tournament requires trusted server-side scoring, eligibility checks, and reward settlement.
- Existing profiles that were already registered in the previous free tournament lobby may have an old registration entry. Such profiles may need a fresh Firebase test account to test the new 50-coin entry flow.
