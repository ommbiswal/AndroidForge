Cricket Card Boli Battle v2.5 - Daily Quiz + Tournament Rewards + History

New in v2.5:
- Daily Quiz Challenge: one rewarded attempt per local calendar day.
- Daily Quiz rewards: 5 virtual coins per correct answer, plus 20 bonus coins for 8/10 or better, and 10 XP.
- Tournament results automatically lock when every registered player has submitted their first Solo Quiz score.
- Tournament history is saved under tournaments/history using the existing Firebase tournaments rules.
- Top 3 rewards: 500 / 300 / 150 virtual coins. Each winner receives their own reward automatically when their app checks the completed tournament.
- Tournament registration is closed after that tournament is settled.

Build and test:
1. Upload this ZIP to AndroidForge and build the APK.
2. Install the APK. Firebase rules do not need a change from the v2.3 rules already published.
3. Open Quiz Battle > Daily Quiz Challenge, complete all 10 questions, and check the coin balance.
4. Each player joins the Online Quiz Tournament (50 coins), then completes one Solo Challenge.
5. When all registered players have played, the tournament locks and history is saved. Winners receive their reward when they open the app while online.

Important limitations:
- Coins are virtual in-app points only; no cash or real-money prizes.
- This beta uses client-side quiz scoring and the existing broad beta database rules. It is not cheat-proof and is not suitable for paid competitions.
- Winner coin credit is restricted to the signed-in player's own profile; each winner's app applies their reward when it checks the settled leaderboard.
- Only one open tournament is implemented in this beta; after it settles, new registrations are closed until a future update creates a new tournament season.
